# Legal Yoddha

Instructions to upload on GitHub or Firebase.